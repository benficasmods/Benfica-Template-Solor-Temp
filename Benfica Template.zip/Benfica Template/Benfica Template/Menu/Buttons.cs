﻿using StupidTemplate.Classes;
using StupidTemplate.Mods;
using static StupidTemplate.Settings;

namespace StupidTemplate.Menu
{
    internal class Buttons
    {
        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
            new ButtonInfo[] { // Main Mods
                new ButtonInfo { buttonText = "Settings", method =() => SettingsMods.EnterSettings(), isTogglable = false},
                new ButtonInfo { buttonText = "Network", method =() => SettingsMods.EnterNetwork(), isTogglable = false},
                new ButtonInfo { buttonText = "Safety", method =() => SettingsMods.EnterSafety(), isTogglable = false},
                new ButtonInfo { buttonText = "Player", method =() => SettingsMods.EnterPlayer(), isTogglable = false},
                new ButtonInfo { buttonText = "World", method =() => SettingsMods.EnterWorld(), isTogglable = false},
                new ButtonInfo { buttonText = "Movement", method =() => SettingsMods.EnterMovement(), isTogglable = false},
                new ButtonInfo { buttonText = "Visuals", method =() => SettingsMods.EnterVisuals(), isTogglable = false},
                new ButtonInfo { buttonText = "Annyoing", method =() => SettingsMods.EnterAnnyoing(), isTogglable = false},
                new ButtonInfo { buttonText = "Op", method =() => SettingsMods.EnterOP(), isTogglable = false},
            },

            new ButtonInfo[] { // Settings
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false},
                new ButtonInfo { buttonText = "Right Hand", enableMethod =() => SettingsMods.RightHand(), disableMethod =() => SettingsMods.LeftHand(), isTogglable = true},
                new ButtonInfo { buttonText = "Notifications", enableMethod =() => SettingsMods.EnableNotifications(), disableMethod =() => SettingsMods.DisableNotifications(), enabled = !disableNotifications},
                new ButtonInfo { buttonText = "FPS Counter", enableMethod =() => SettingsMods.EnableFPSCounter(), disableMethod =() => SettingsMods.DisableFPSCounter(), enabled = fpsCounter},
                new ButtonInfo { buttonText = "Disconnect Button", enableMethod =() => SettingsMods.EnableDisconnectButton(), disableMethod =() => SettingsMods.DisableDisconnectButton(), enabled = disconnectButton},
                new ButtonInfo { buttonText = "Outline", enableMethod =() => SettingsMods.EnOutline(), disableMethod =() => SettingsMods.DisOutline(), enabled = false},
                new ButtonInfo { buttonText = "Return Button", enableMethod =() => SettingsMods.EnUsl(), disableMethod =() => SettingsMods.DisUsl(), enabled = false},
                new ButtonInfo { buttonText = "Button Sound:", overlapText = "Button Sound: <color=white>[Wood]</color>", method =() => SettingsMods.BtnSoundChanger(), isTogglable = false},
                new ButtonInfo { buttonText = "First Color:", overlapText = "First Color: <color=white>[Dark Grey]</color>", method =() => SettingsMods.Color1Menu(), isTogglable = false},
                new ButtonInfo { buttonText = "Disconnect Color:", overlapText = "Disconnect Color: <color=white>[Dark Grey]</color>", method =() => SettingsMods.Color2Disconnect(), isTogglable = false},
                new ButtonInfo { buttonText = "Enabled Button Color:", overlapText = "Enabled Button Color: <color=white>[Dark Grey]</color>", method =() => SettingsMods.Color3EnBtn(), isTogglable = false},
                new ButtonInfo { buttonText = "Disabled Button Color:", overlapText = "Disabled Button Color: <color=white>[Dark Grey]</color>", method =() => SettingsMods.Color4DisBtn(), isTogglable = false},
                new ButtonInfo { buttonText = "Last Page Button Color:", overlapText = "Last Page Button Color: <color=white>[Dark Grey]</color>", method =() => SettingsMods.Color5Prv(), isTogglable = false},
                new ButtonInfo { buttonText = "Next Page Button Color:", overlapText = "Next Page Button Color: <color=white>[Dark Grey]</color>", method =() => SettingsMods.Color6Next(), isTogglable = false},
                new ButtonInfo { buttonText = "Button Text Color:", overlapText = "Button Text Color: <color=white>[White]</color>", method =() => SettingsMods.Color8ButtonText(), isTogglable = false},
                new ButtonInfo { buttonText = "BackGround Color:", overlapText = "BackGround Color: <color=white>[Dark Grey]</color>", method =() => SettingsMods.Color9BackGround(), isTogglable = false},
                new ButtonInfo { buttonText = "Gun Line Color:", overlapText = "Gun Line Color: <color=white>[Dark Grey]</color>", method =() => SettingsMods.Color11GunLine(), isTogglable = false},
                new ButtonInfo { buttonText = "Fly Speed:", overlapText = "Fly Speed: <color=white>[15f]</color>", method =() => SettingsMods.SpeedForFly(), isTogglable = false},
                new ButtonInfo { buttonText = "Speed Boost Speed:", overlapText = "Speed Boost Speed: <color=white>[6.5f/Normal]</color>", method =() => SettingsMods.SpeedForBoost(), isTogglable = false},
                new ButtonInfo { buttonText = "Long Arms Size:", overlapText = "Long Arms Size: <color=white>[1.1f]</color>", method =() => SettingsMods.ChangeLongArms(), isTogglable = false},
                new ButtonInfo { buttonText = "Save Preferences", enableMethod =() => SettingsMods.SavePrefs(), isTogglable = true, enabled = false},
                new ButtonInfo { buttonText = "Load Preferences", enableMethod =() => SettingsMods.LoadPrefs(), isTogglable = true, enabled = false},
            },


            new ButtonInfo[] { // Network
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false},
            },

            new ButtonInfo[] { // Safety
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false},
            },

            new ButtonInfo[] { // Player
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false},
            },

            new ButtonInfo[] { // World
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false},
            },

            new ButtonInfo[] { // Movement
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false},
                new ButtonInfo { buttonText = "Platforms <color=white>[Normal]</color>", method =() => Global.Platforms(), isTogglable = true},
                new ButtonInfo { buttonText = "Platforms <color=white>[Sticky]</color>", method =() => Global.StickyPlates(), isTogglable = true},
                new ButtonInfo { buttonText = "Platforms <color=white>[Invis]</color>", method =() => Global.InvisPlates(), isTogglable = true},
                new ButtonInfo { buttonText = "Trigger Platforms <color=white>[Normal]</color>", method =() => Global.TrigPlatforms(), isTogglable = true},
                new ButtonInfo { buttonText = "Trigger Platforms <color=white>[Sticky]</color>", method =() => Global.TrigStickyPlates(), isTogglable = true},
                new ButtonInfo { buttonText = "Trigger Platforms <color=white>[Invis]</color>", method =() => Global.TrigInvisPlates(), isTogglable = true},
            },

            new ButtonInfo[] { // Visuals
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false},
                new ButtonInfo { buttonText = "FPC (60)", method =() => Global.fpc60(), isTogglable = true},
                new ButtonInfo { buttonText = "FPC (70)", method =() => Global.fpc70(), isTogglable = true},
                new ButtonInfo { buttonText = "FPC (80)", method =() => Global.fpc80(), isTogglable = true},
                new ButtonInfo { buttonText = "FPC (90)", method =() => Global.fpc90(), isTogglable = true},
                new ButtonInfo { buttonText = "FPC (100)", method =() => Global.fpc100(), isTogglable = true},
                new ButtonInfo { buttonText = "FPC (110)", method =() => Global.fpc110(), isTogglable = true},
                new ButtonInfo { buttonText = "FPC (120)", method =() => Global.fpc120(), isTogglable = true},
            },

            new ButtonInfo[] { // Annyoing
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false},
                
            },

            new ButtonInfo[] { // Op
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false},
            },
        };
    }
}
