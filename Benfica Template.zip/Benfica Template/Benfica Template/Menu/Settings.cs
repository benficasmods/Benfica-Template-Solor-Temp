﻿using StupidTemplate.Classes;
using UnityEngine;
using static StupidTemplate.Menu.Main;

namespace StupidTemplate
{
    internal class Settings
    {
        public static ExtGradient backgroundColor = new ExtGradient { isRainbow = false };
        public static ExtGradient[] buttonColors = new ExtGradient[]
        {
            new ExtGradient{colors = GetSolidGradient(new Color32(34,34,34,34)) }, // Disabled
            new ExtGradient{isRainbow = false} // Enabled
        };
        public static Color[] textColors = new Color[]
        {
            Color.white, // Disabled
            Color.white // Enabled
        };

        public static Font currentFont = (Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font);

        public static bool fpsCounter = true;
        public static bool disconnectButton = true;
        public static bool Useless = false;
        public static bool rightHanded = false;
        public static bool disableNotifications = false;
        public static bool Outline = false;
        public static bool GunLiner = false;
        public static bool ModLister = false;

        public static KeyCode keyboardButton = KeyCode.Q;
        public static Color32 MenuColor = new Color32(34, 34, 34, 34);
        public static Color32 DisColor = new Color32(34, 34, 34, 34);
        public static Color32 RetColor = new Color32(34, 34, 34, 34);
        public static Color32 NextNPrvColor = new Color32(34, 34, 34, 34);
        public static Color32 NextNPrvColor2 = new Color32(34, 34, 34, 34);
        public static Color32 ModBtnColor = new Color32(34, 34, 34, 34);
        public static Color32 ModBtnColor2 = new Color32(34, 34, 34, 34);
        public static Color32 OutlineColor1 = new Color32(34, 34, 34, 34);
        public static Color32 ButtonTextColor = Color.white;
        public static Color32 GunBall = Color.black;
        public static Color32 GunLine = new Color32(34, 34, 34, 34);
        public static Color32 BackGroundColor = new Color32(34, 34, 34, 34);

        public static Vector3 menuSize = new Vector3(0.1f, 1f, 1f); // Depth, Width, Height
        public static int buttonsPerPage = 8;
    }
}
