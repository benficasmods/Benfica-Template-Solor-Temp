﻿using StupidTemplate.Classes;
using StupidTemplate.Menu;
using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using static StupidTemplate.Menu.Main;
using static StupidTemplate.Settings;

namespace StupidTemplate.Mods
{
    internal class SettingsMods
    {
        public static void EnterSettings()
        {
            buttonsType = 1;
            pageNumber = 0;
        }

        public static void EnterNetwork()
        {
            buttonsType = 2;
            pageNumber = 0;
        }

        public static void EnterSafety()
        {
            buttonsType = 3;
            pageNumber = 0;
        }

        public static void EnterPlayer()
        {
            buttonsType = 4;
            pageNumber = 0;
        }

        public static void EnterWorld()
        {
            buttonsType = 5;
            pageNumber = 0;
        }

        public static void EnterMovement()
        {
            buttonsType = 6;
            pageNumber = 0;
        }

        public static void EnterVisuals()
        {
            buttonsType = 7;
            pageNumber = 0;
        }

        public static void EnterAnnyoing()
        {
            buttonsType = 8;
            pageNumber = 0;
        }

        public static void EnterOP()
        {
            buttonsType = 9;
            pageNumber = 0;
        }

        public static void RightHand()
        {
            rightHanded = true;
        }

        public static void LeftHand()
        {
            rightHanded = false;
        }

        public static void EnableFPSCounter()
        {
            fpsCounter = true;
        }

        public static void DisableFPSCounter()
        {
            fpsCounter = false;
        }

        public static void EnableNotifications()
        {
            disableNotifications = false;
        }

        public static void DisableNotifications()
        {
            disableNotifications = true;
        }

        public static void DisOutline()
        {
            Outline = false;
        }
        public static void EnOutline()
        {
            Outline = true;
        }

        public static void EnUsl()
        {
            Useless = true;
        }
        public static void DisUsl()
        {
            Useless = false;
        }

        public static void EnableGunLine()
        {
            GunLiner = true;
        }
        public static void DisableGunLine()
        {
            GunLiner = false;
        }

        public static void EnableDisconnectButton()
        {
            disconnectButton = true;
        }

        public static void DisableDisconnectButton()
        {
            disconnectButton = false;
        }

        private static int Color1;
        public static void Color1Menu()
        {
            Color1++;
            if (Color1 == 0)
            {
                MenuColor = new Color32(34, 34, 34, 34);
            }
            if (Color1 == 1)
            {
                MenuColor = new Color32(25, 15, 165, 0);
            }
            if (Color1 == 2)
            {
                MenuColor = new Color32(101, 41, 138, 255);
            }
            if (Color1 == 3)
            {
                MenuColor = new Color32(0,0,0,0);
            }
            if (Color1 == 4)
            {
                MenuColor = new Color32(255, 0, 129, 255);
            }
            if (Color1 == 5)
            {
                MenuColor = new Color32(152, 255, 152, 1);
            }
            if (Color1 == 6)
            {
                MenuColor = Color.red;
            }
            if (Color1 == 7)
            {
                MenuColor = Color.yellow;
            }
            if (Color1 == 8)
            {
                MenuColor = Color.green;
            }
            if (Color1 == 9)
            {
                MenuColor = Color.white;
            }
            if (Color1 == 10)
            {
                Color1 = 0;
                MenuColor = new Color32(34, 34, 34, 34);
            }
            string[] array = new string[]
            {
                "Dark Grey",
                "Dark Blue",
                "Purple",
                "Black",
                "Bubble Gum Pink",
                "Mint Green",
                "Red",
                "Yellow",
                "Green",
                "White",
                "Dark Grey",
            };
            string[] time = new string[] { "Dark Grey", "Dark Blue", "Purple", "Black", "BubbleGum Pink", "Mint Green", "Red", "Yellow", "Green", "White", "Dark Grey" };
            Main.GetIndex("First Color:").overlapText = "First Color: <color=white>[</color><color=white>" + time[Color1] + "</color><color=white>]</color>";
        }

        private static int Color2;
        public static void Color2Disconnect()
        {
            Color2++;
            if (Color2 == 0)
            {
                DisColor = new Color32(34, 34, 34, 34);
            }
            if (Color2 == 1)
            {
                DisColor = new Color32(25, 15, 165, 0);
            }
            if (Color2 == 2)
            {
                DisColor = new Color32(101, 41, 138, 255);
            }
            if (Color2 == 3)
            {
                DisColor = new Color32(0, 0, 0, 0);
            }
            if (Color2 == 4)
            {
                DisColor = new Color32(255, 0, 129, 255);
            }
            if (Color2 == 5)
            {
                DisColor = new Color32(152, 255, 152, 1);
            }
            if (Color2 == 6)
            {
                DisColor = Color.red;
            }
            if (Color2 == 7)
            {
                DisColor = Color.yellow;
            }
            if (Color2 == 8)
            {
                DisColor = Color.green;
            }
            if (Color2 == 9)
            {
                DisColor = Color.white;
            }
            if (Color2 == 10)
            {
                Color2 = 0;
                DisColor = new Color32(34, 34, 34, 34);
            }
            string[] array = new string[]
            {
                "Dark Grey",
                "Dark Blue",
                "Purple",
                "Black",
                "Bubble Gum Pink",
                "Mint Green",
                "Red",
                "Yellow",
                "Green",
                "White",
                "Dark Grey",
            };
            string[] time = new string[] { "Dark Grey", "Dark Blue", "Purple", "Black", "BubbleGum Pink", "Mint Green", "Red", "Yellow", "Green", "White", "Dark Grey" };
            Main.GetIndex("Disconnect Color:").overlapText = "Disconnect Color: <color=white>[</color><color=white>" + time[Color2] + "</color><color=white>]</color>";
        }

        private static int Color3;
        public static void Color3EnBtn()
        {
            Color3++;
            if (Color3 == 0)
            {
                ModBtnColor = new Color32(34, 34, 34, 34);
            }
            if (Color3 == 1)
            {
                ModBtnColor = new Color32(25, 15, 165, 0);
            }
            if (Color3 == 2)
            {
                ModBtnColor = new Color32(101, 41, 138, 255);
            }
            if (Color3 == 3)
            {
                ModBtnColor = new Color32(0, 0, 0, 0);
            }
            if (Color3 == 4)
            {
                ModBtnColor = new Color32(255, 0, 129, 255);
            }
            if (Color3 == 5)
            {
                ModBtnColor = new Color32(152, 255, 152, 1);
            }
            if (Color3 == 6)
            {
                ModBtnColor = Color.red;
            }
            if (Color3 == 7)
            {
                ModBtnColor = Color.yellow;
            }
            if (Color3 == 8)
            {
                ModBtnColor = Color.green;
            }
            if (Color3 == 9)
            {
                ModBtnColor = Color.white;
            }
            if (Color3 == 10)
            {
                Color3 = 0;
                ModBtnColor = new Color32(34, 34, 34, 34);
            }
            string[] array = new string[]
            {
                "Dark Grey",
                "Dark Blue",
                "Purple",
                "Black",
                "Bubble Gum Pink",
                "Mint Green",
                "Red",
                "Yellow",
                "Green",
                "White",
                "Dark Grey",
            };
            string[] time = new string[] { "Dark Grey", "Dark Blue", "Purple", "Black", "BubbleGum Pink", "Mint Green", "Red", "Yellow", "Green", "White", "Dark Grey" };
            Main.GetIndex("Enabled Button Color:").overlapText = "Enabled Button Color: <color=white>[</color><color=white>" + time[Color3] + "</color><color=white>]</color>";
        }


        private static int Color4;
        public static void Color4DisBtn()
        {
            Color4++;
            if (Color4 == 0)
            {
                ModBtnColor2 = new Color32(34, 34, 34, 34);
            }
            if (Color4 == 1)
            {
                ModBtnColor2 = new Color32(25, 15, 165, 0);
            }
            if (Color4 == 2)
            {
                ModBtnColor2 = new Color32(101, 41, 138, 255);
            }
            if (Color4 == 3)
            {
                ModBtnColor2 = new Color32(0, 0, 0, 0);
            }
            if (Color4 == 4)
            {
                ModBtnColor2 = new Color32(255, 0, 129, 255);
            }
            if (Color4 == 5)
            {
                ModBtnColor2 = new Color32(152, 255, 152, 1);
            }
            if (Color4 == 6)
            {
                ModBtnColor2 = Color.red;
            }
            if (Color4 == 7)
            {
                ModBtnColor2 = Color.yellow;
            }
            if (Color4 == 8)
            {
                ModBtnColor2 = Color.green;
            }
            if (Color4 == 9)
            {
                ModBtnColor2 = Color.white;
            }
            if (Color4 == 10)
            {
                Color4 = 0;
                ModBtnColor2 = new Color32(34, 34, 34, 34);
            }
            string[] array = new string[]
            {
                "Dark Grey",
                "Dark Blue",
                "Purple",
                "Black",
                "Bubble Gum Pink",
                "Mint Green",
                "Red",
                "Yellow",
                "Green",
                "White",
                "Dark Grey",
            };
            string[] time = new string[] { "Dark Grey", "Dark Blue", "Purple", "Black", "BubbleGum Pink", "Mint Green", "Red", "Yellow", "Green", "White", "Dark Grey" };
            Main.GetIndex("Disabled Button Color:").overlapText = "Disabled Button Color: <color=white>[</color><color=white>" + time[Color4] + "</color><color=white>]</color>";
        }

        private static int Color5;
        public static void Color5Prv()
        {
            Color5++;
            if (Color5 == 0)
            {
                NextNPrvColor = new Color32(34, 34, 34, 34);
            }
            if (Color5 == 1)
            {
                NextNPrvColor = new Color32(25, 15, 165, 0);
            }
            if (Color5 == 2)
            {
                NextNPrvColor = new Color32(101, 41, 138, 255);
            }
            if (Color5 == 3)
            {
                NextNPrvColor = new Color32(0, 0, 0, 0);
            }
            if (Color5 == 4)
            {
                NextNPrvColor = new Color32(255, 0, 129, 255);
            }
            if (Color5 == 5)
            {
                NextNPrvColor = new Color32(152, 255, 152, 1);
            }
            if (Color5 == 6)
            {
                NextNPrvColor = Color.red;
            }
            if (Color5 == 7)
            {
                NextNPrvColor = Color.yellow;
            }
            if (Color5 == 8)
            {
                NextNPrvColor = Color.green;
            }
            if (Color5 == 9)
            {
                NextNPrvColor = Color.white;
            }
            if (Color5 == 10)
            {
                Color5 = 0;
                NextNPrvColor = new Color32(34, 34, 34, 34);
            }
            string[] array = new string[]
            {
                "Dark Grey",
                "Dark Blue",
                "Purple",
                "Black",
                "Bubble Gum Pink",
                "Mint Green",
                "Red",
                "Yellow",
                "Green",
                "White",
                "Dark Grey",
            };
            string[] time = new string[] { "Dark Grey", "Dark Blue", "Purple", "Black", "BubbleGum Pink", "Mint Green", "Red", "Yellow", "Green", "White", "Dark Grey" };
            Main.GetIndex("Last Page Button Color:").overlapText = "Last Page Button Color: <color=white>[</color><color=white>" + time[Color5] + "</color><color=white>]</color>";
        }

        private static int Color6;
        public static void Color6Next()
        {
            Color6++;
            if (Color6 == 0)
            {
                NextNPrvColor2 = new Color32(34, 34, 34, 34);
            }
            if (Color6 == 1)
            {
                NextNPrvColor2 = new Color32(25, 15, 165, 0);
            }
            if (Color6 == 2)
            {
                NextNPrvColor2 = new Color32(101, 41, 138, 255);
            }
            if (Color6 == 3)
            {
                NextNPrvColor2 = new Color32(0, 0, 0, 0);
            }
            if (Color6 == 4)
            {
                NextNPrvColor2 = new Color32(255, 0, 129, 255);
            }
            if (Color6 == 5)
            {
                NextNPrvColor2 = new Color32(152, 255, 152, 1);
            }
            if (Color6 == 6)
            {
                NextNPrvColor2 = Color.red;
            }
            if (Color6 == 7)
            {
                NextNPrvColor2 = Color.yellow;
            }
            if (Color6 == 8)
            {
                NextNPrvColor2 = Color.green;
            }
            if (Color6 == 9)
            {
                NextNPrvColor2 = Color.white;
            }
            if (Color6 == 10)
            {
                Color6 = 0;
                NextNPrvColor2 = new Color32(34, 34, 34, 34);
            }
            string[] array = new string[]
            {
                "Dark Grey",
                "Dark Blue",
                "Purple",
                "Black",
                "Bubble Gum Pink",
                "Mint Green",
                "Red",
                "Yellow",
                "Green",
                "White",
                "Dark Grey",
            };
            string[] time = new string[] { "Dark Grey", "Dark Blue", "Purple", "Black", "BubbleGum Pink", "Mint Green", "Red", "Yellow", "Green", "White", "Dark Grey" };
            Main.GetIndex("Next Page Button Color:").overlapText = "Next Page Button Color: <color=white>[</color><color=white>" + time[Color6] + "</color><color=white>]</color>";
        }

        private static int Color7;
        public static void Color7Outline()
        {
            Color7++;
            if (Color7 == 0)
            {
                OutlineColor1 = Color.white;
            }
            if (Color7 == 1)
            {
                OutlineColor1 = new Color32(25, 15, 165, 0);
            }
            if (Color7 == 2)
            {
                OutlineColor1 = new Color32(101, 41, 138, 255);
            }
            if (Color7 == 3)
            {
                OutlineColor1 = new Color32(0, 0, 0, 0);
            }
            if (Color7 == 4)
            {
                OutlineColor1 = new Color32(255, 0, 129, 255);
            }
            if (Color7 == 5)
            {
                OutlineColor1 = new Color32(152, 255, 152, 1);
            }
            if (Color7 == 6)
            {
                OutlineColor1 = Color.red;
            }
            if (Color7 == 7)
            {
                OutlineColor1 = Color.yellow;
            }
            if (Color7 == 8)
            {
                OutlineColor1 = Color.green;
            }
            if (Color7 == 9)
            {
                OutlineColor1 = new Color32(34, 34, 34, 34);
            }
            if (Color7 == 10)
            {
                Color7 = 0;
                OutlineColor1 = Color.white;
            }
            string[] array = new string[]
            {
                "Dark Grey",
                "Dark Blue",
                "Purple",
                "Black",
                "Bubble Gum Pink",
                "Mint Green",
                "Red",
                "Yellow",
                "Green",
                "White",
                "Dark Grey",
            };
            string[] time = new string[] { "White", "Dark Blue", "Purple", "Black", "BubbleGum Pink", "Mint Green", "Red", "Yellow", "Green", "Dark Grey", "White" };
            Main.GetIndex("Outline Color:").overlapText = "Outline Color: <color=white>[</color><color=white>" + time[Color7] + "</color><color=white>]</color>";
        }

        private static int Color8;
        public static void Color8ButtonText()
        {
            Color8++;
            if (Color8 == 0)
            {
                ButtonTextColor = new Color32(34, 34, 34, 34);
            }
            if (Color8 == 1)
            {
                ButtonTextColor = new Color32(25, 15, 165, 0);
            }
            if (Color8 == 2)
            {
                ButtonTextColor = new Color32(101, 41, 138, 255);
            }
            if (Color8 == 3)
            {
                ButtonTextColor = new Color32(0, 0, 0, 0);
            }
            if (Color8 == 4)
            {
                ButtonTextColor = new Color32(255, 0, 129, 255);
            }
            if (Color8 == 5)
            {
                ButtonTextColor = new Color32(152, 255, 152, 1);
            }
            if (Color8 == 6)
            {
                ButtonTextColor = Color.red;
            }
            if (Color8 == 7)
            {
                ButtonTextColor = Color.yellow;
            }
            if (Color8 == 8)
            {
                ButtonTextColor = Color.green;
            }
            if (Color8 == 9)
            {
                ButtonTextColor = new Color32(34, 34, 34, 34);
            }
            if (Color8 == 10)
            {
                Color8 = 0;
                ButtonTextColor = new Color32(255, 255, 255, 255);
            }
            string[] array = new string[]
            {
                "White",
                "Dark Blue",
                "Purple",
                "Black",
                "Bubble Gum Pink",
                "Mint Green",
                "Red",
                "Yellow",
                "Green",
                "Dark Grey",
                "White",
            };
            string[] time = new string[] { "White", "Dark Blue", "Purple", "Black", "BubbleGum Pink", "Mint Green", "Red", "Yellow", "Green", "Dark Grey", "White" };
            Main.GetIndex("Button Text Color:").overlapText = "Button Text Color: <color=white>[</color><color=white>" + time[Color8] + "</color><color=white>]</color>";
        }

        private static int Color9;
        public static void Color9BackGround()
        {
            Color9++;
            if (Color9 == 0)
            {
                BackGroundColor = new Color32(34, 34, 34, 34);
            }
            if (Color9 == 1)
            {
                BackGroundColor = new Color32(25, 15, 165, 0);
            }
            if (Color9 == 2)
            {
                BackGroundColor = new Color32(101, 41, 138, 255);
            }
            if (Color9 == 3)
            {
                BackGroundColor = new Color32(0, 0, 0, 0);
            }
            if (Color9 == 4)
            {
                BackGroundColor = new Color32(255, 0, 129, 255);
            }
            if (Color9 == 5)
            {
                BackGroundColor = new Color32(152, 255, 152, 1);
            }
            if (Color9 == 6)
            {
                BackGroundColor = Color.red;
            }
            if (Color9 == 7)
            {
                BackGroundColor = Color.yellow;
            }
            if (Color9 == 8)
            {
                BackGroundColor = Color.green;
            }
            if (Color9 == 9)
            {
                BackGroundColor = Color.white;
            }
            if (Color9 == 10)
            {
                Color9 = 0;
                BackGroundColor = new Color32(34, 34, 34, 34);
            }
            string[] array = new string[]
            {
                "Dark Grey",
                "Dark Blue",
                "Purple",
                "Black",
                "Bubble Gum Pink",
                "Mint Green",
                "Red",
                "Yellow",
                "Green",
                "White",
                "Dark Grey",
            };
            string[] time = new string[] { "Dark Grey", "Dark Blue", "Purple", "Black", "BubbleGum Pink", "Mint Green", "Red", "Yellow", "Green", "White", "Dark Grey" };
            Main.GetIndex("BackGround Color:").overlapText = "BackGround Color: <color=white>[</color><color=white>" + time[Color9] + "</color><color=white>]</color>";
        }

        private static int Color10;
        public static void Color10Ball()
        {
            Color10++;
            if (Color10 == 0)
            {
                GunBall = new Color32(34, 34, 34, 34);
            }
            if (Color10 == 1)
            {
                GunBall = new Color32(25, 15, 165, 0);
            }
            if (Color10 == 2)
            {
                GunBall = new Color32(101, 41, 138, 255);
            }
            if (Color10 == 3)
            {
                GunBall = new Color32(0, 0, 0, 0);
            }
            if (Color10 == 4)
            {
                GunBall = new Color32(255, 0, 129, 255);
            }
            if (Color10 == 5)
            {
                GunBall = new Color32(152, 255, 152, 1);
            }
            if (Color10 == 6)
            {
                GunBall = Color.red;
            }
            if (Color10 == 7)
            {
                GunBall = Color.yellow;
            }
            if (Color10 == 8)
            {
                GunBall = Color.green;
            }
            if (Color10 == 9)
            {
                GunBall = Color.white;
            }
            if (Color10 == 10)
            {
                Color10 = 0;
                GunBall = new Color32(34, 34, 34, 34);
            }
            string[] array = new string[]
            {
                "Dark Grey",
                "Dark Blue",
                "Purple",
                "Black",
                "Bubble Gum Pink",
                "Mint Green",
                "Red",
                "Yellow",
                "Green",
                "White",
                "Dark Grey",
            };
            string[] time = new string[] { "Dark Grey", "Dark Blue", "Purple", "Black", "BubbleGum Pink", "Mint Green", "Red", "Yellow", "Green", "White", "Dark Grey" };
            Main.GetIndex("Gun Ball Color:").overlapText = "Gun Ball Color: <color=white>[</color><color=white>" + time[Color10] + "</color><color=white>]</color>";
        }

        private static int Color11;
        public static void Color11GunLine()
        {
            Color11++;
            if (Color11 == 0)
            {
                GunLine = new Color32(34, 34, 34, 34);
            }
            if (Color11 == 1)
            {
                GunLine = new Color32(25, 15, 165, 0);
            }
            if (Color11 == 2)
            {
                GunLine = new Color32(101, 41, 138, 255);
            }
            if (Color11 == 3)
            {
                GunLine = new Color32(0, 0, 0, 0);
            }
            if (Color11 == 4)
            {
                GunLine = new Color32(255, 0, 129, 255);
            }
            if (Color11 == 5)
            {
                GunLine = new Color32(152, 255, 152, 1);
            }
            if (Color11 == 6)
            {
                GunLine = Color.red;
            }
            if (Color11 == 7)
            {
                GunLine = Color.yellow;
            }
            if (Color11 == 8)
            {
                GunLine = Color.green;
            }
            if (Color11 == 9)
            {
                GunLine = Color.white;
            }
            if (Color11 == 10)
            {
                Color11 = 0;
                GunLine = new Color32(34, 34, 34, 34);
            }
            string[] array = new string[]
            {
                "Dark Grey",
                "Dark Blue",
                "Purple",
                "Black",
                "Bubble Gum Pink",
                "Mint Green",
                "Red",
                "Yellow",
                "Green",
                "White",
                "Dark Grey",
            };
            string[] time = new string[] { "Dark Grey", "Dark Blue", "Purple", "Black", "BubbleGum Pink", "Mint Green", "Red", "Yellow", "Green", "White", "Dark Grey" };
            Main.GetIndex("Gun Line Color:").overlapText = "Gun Line Color: <color=white>[</color><color=white>" + time[Color11] + "</color><color=white>]</color>";
        }

        public static int BtnSound = 8;
        private static int SoundChanger = 0;
        public static void BtnSoundChanger()
        {
            SoundChanger++;
            if (SoundChanger == 0)
            {
                BtnSound = 66;
            }
            if (SoundChanger == 1)
            {
                BtnSound = 66;
            }
            if (SoundChanger == 2)
            {
                BtnSound = 67;
            }
            if (SoundChanger == 3)
            {
                BtnSound = 106;
            }
            if (SoundChanger == 4)
            {
                BtnSound = 99;
            }
            if (SoundChanger == 5)
            {
                BtnSound = 144;
            }
            if (SoundChanger == 6)
            {
                BtnSound = 123;
            }
            if (SoundChanger == 7)
            {
                BtnSound = 8;
                SoundChanger = 0;
            }
            string[] array = new string[]
            {
                "Wood",
                "Keyboard",
                "Default",
                "Jar",
                "Leaf",
                "Stool",
                "Wooden Shelf",
                "Wood",
            };
            string[] time = new string[] {"Wood", "Keyboard", "Default", "Jar", "Leaf", "Stool", "GiantOrnamentRound", "Wood"};
            Main.GetIndex("Button Sound:").overlapText = "Button Sound: <color=white>[</color><color=white>" + time[SoundChanger] + "</color><color=white>]</color>";
        }

        public static float flysped = 15f;
        private static int Speed;
        public static void SpeedForFly()
        {
            Speed++;
            if (Speed == 0)
            {
                flysped = 15f;
            }
            if (Speed == 1)
            {
                flysped = 18f;
            }
            if (Speed == 2)
            {
                flysped = 20f;
            }
            if (Speed == 3)
            { 
                flysped = 25f;
            }
            if (Speed == 4)
            {
                flysped = 30f;
            }
            if (Speed == 5)
            {
                flysped = 35f;
            }
            if (Speed == 6)
            {
                flysped = 38f;
            }
            if (Speed == 7)
            {
                flysped = 40f;
            }
            if (Speed == 8)
            {
                flysped = 45f;
            }
            if (Speed == 9)
            {
                flysped = 50f;
            }
            if (Speed == 10)
            {
                Speed = 0;
                flysped = 15f;
            }
            string[] array = new string[]
            {
                "15f",
                "18f",
                "20f",
                "25f",
                "30f",
                "35f",
                "38f",
                "40f",
                "45f",
                "50f",
                "15f",
            };
            string[] time = new string[] { "15f", "18f", "20f", "25f", "30f", "35f", "38f", "40f", "45f", "50f", "15f" };
            Main.GetIndex("Fly Speed:").overlapText = "Fly Speed: <color=white>[</color><color=white>" + time[Speed] + "</color><color=white>]</color>";
        }

        public static float SpedBoostsped = 6.5f;
        private static int SpeedBust;
        public static void SpeedForBoost()
        {
            SpeedBust++;
            if (SpeedBust == 0)
            {
                SpedBoostsped = 6.5f;
            }
            if (SpeedBust == 1)
            {
                SpedBoostsped = 7f;
            }
            if (SpeedBust == 2)
            {
                SpedBoostsped = 7.5f;
            }
            if (SpeedBust == 3)
            {
                SpedBoostsped = 8f;
            }
            if (SpeedBust == 4)
            {
                SpedBoostsped = 8.5f;
            }
            if (SpeedBust == 5)
            {
                SpedBoostsped = 9f;
            }
            if (SpeedBust == 6)
            {
                SpedBoostsped = 9.5f;
            }
            if (SpeedBust == 7)
            {
                SpedBoostsped = 10f;
            }
            if (SpeedBust == 8)
            {
                SpedBoostsped = 10.5f;
            }
            if (SpeedBust == 9)
            {
                SpedBoostsped = 11f;
            }
            if (SpeedBust == 10)
            {
                SpeedBust = 0;
                SpedBoostsped = 6.5f;
            }
            string[] array = new string[]
            {
                "6.5f/Normal",
                "7f",
                "7.5f [Mosa]", 
                "8f", 
                "8.5f",
                "9f", 
                "9.5f",
                "10f", 
                "10.5f",
                "11f",
                "6.5f/Normal",
            };
            string[] time = new string[] { "6.5f/Normal", "7f", "7.5f [Mosa]", "8f", "8.5f", "9f", "9.5f", "10f", "10.5f", "11f", "6.5f/Normal" };
            Main.GetIndex("Speed Boost Speed:").overlapText = "Speed Boost Speed: <color=white>[</color><color=white>" + time[SpeedBust] + "</color><color=white>]</color>";
        }

        public static float armLenght = 1.1f;
        private static int Lentgh;
        public static void ChangeLongArms()
        {
            Lentgh++;
            if (Lentgh == 0)
            {
                armLenght = 1.1f;
            }
            if (Lentgh == 1)
            {
                armLenght = 1.2f;
            }
            if (Lentgh == 2)
            {
                armLenght = 1.3f;
            }
            if (Lentgh == 3)
            {
                armLenght = 1.4f;
            }
            if (Lentgh == 4)
            {
                armLenght = 2f;
            }
            if (Lentgh == 5)
            {
                armLenght = 3f;
            }
            if (Lentgh == 6)
            {
                armLenght = 3.5f;
            }
            if (Lentgh == 7)
            {
                armLenght = 5f;
            }
            if (Lentgh == 8)
            {
                armLenght = 0.8f;
            }
            if (Lentgh == 9)
            {
                armLenght = 0.9f;
            }
            if (Lentgh == 10)
            {
                Lentgh = 0;
                armLenght = 1.1f;
            }
            string[] array = new string[]
            {
                "1.1f/Normal", "1.2f", "1.3f", "1.4f", "2f", "3f", "3.5f", "5f", "0.8f", "0.9f", "1.1f/Normal",
            };
            string[] time = new string[] { "1.1f/Normal", "1.2f", "1.3f", "1.4f", "2f", "3f", "3.5f", "5f", "0.8f", "0.9f", "1.1f/Normal" };
            Main.GetIndex("Long Arms Size:").overlapText = "Long Arms Size: <color=white>[</color><color=white>" + time[Lentgh] + "</color><color=white>]</color>";
        }

        

        public static void SavePrefs()
        {
            List<String> list = new List<String>();
            foreach (ButtonInfo[] buttons in Menu.Buttons.buttons)
            {
                foreach (ButtonInfo button in buttons)
                {
                    if (button.enabled == true)
                    {
                        list.Add(button.buttonText);
                    }
                }
            }
            System.IO.Directory.CreateDirectory("SolorPrefs");
            System.IO.File.WriteAllLines("SolorPrefs\\SolorPrefs.txt", list);
        }
        public static void LoadPrefs()
        {
            String[] thing = System.IO.File.ReadAllLines("SolorPrefs\\SolorPrefs.txt");
            foreach (String thing2 in thing)
            {
                foreach (ButtonInfo[] buttons in Menu.Buttons.buttons)
                {
                    foreach (ButtonInfo button in buttons)
                    {
                        if (button.buttonText == thing2)
                        {
                            button.enabled = true;
                        }
                    }
                }
            }
        }
    }
}
