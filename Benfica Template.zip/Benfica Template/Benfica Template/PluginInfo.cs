﻿namespace StupidTemplate
{
    internal class PluginInfo
    {
        public const string GUID = "org.solor";
        public const string Name = "Benfica Template";
        public const string Description = "Created by @benficas_mod with love <3";
        public const string Version = "2.0.0";
    }
}
