﻿namespace StupidTemplate
{
    internal class PluginInfo
    {
        public const string GUID = "";
        public const string Name = "Benfica Template";
        public const string Description = "Created by @benficas_mod with love <3";
        public const string Version = "1.0.0";
    }
}
